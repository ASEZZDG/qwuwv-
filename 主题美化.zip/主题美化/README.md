# Termux interface Qurxin 

<img src="/f.jpg" >

#### Qurxin is Termux banner or interface with parroto os shell and Wellcome robot like Jarvis in Iron Man movie created with love 16-oct-2020

## [+] Installation & Usage :atom_symbol:
```
apt update && upgrade -y 
pkg install git python mpv figlet -y
pip install lolcat
git clone https://github.com/fikrado/qurxin
cd qurxin
chmod +x *
sh install.sh
exit
```
### One command installation :octocat:
```
apt update && upgrade -y && apt install git -y && pkg install mpv figlet python && pip install lolcat && git clone https://github.com/fikrado/qurxin && cd qurxin && chmod +x * && ./install.sh
```
## screen shot

<img width="200px" src="/s.jpg" >

## [-] How to remove :electron:
```
cd qurxin

bash rvt.sh
```
# thanks for using my script please donate
<a href="https://liberapay.com/fikrado">
  <img align="center" alt="Yahye's Librabay" width="100px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Liberapay_logo_v2_white-on-yellow.svg/1200px-Liberapay_logo_v2_white-on-yellow.svg.png" />




## [+] Find Me on :

[![Github](https://img.shields.io/badge/Facebook-fikrado-blue?style=for-the-badge&logo=facebook)](https://facebook.com/fikrado4048063)
[![Github](https://img.shields.io/badge/WhatsApp-Mr_Yahye-lightgreen?style=for-the-badge&logo=whatsapp)](https://api.whatsapp.com/send?phone=252634048063)
[![Github](https://img.shields.io/badge/TELEGRAM-MR_Yahye-orange?style=for-the-badge&logo=telegram)](https://t.me/Mr_yahye)
[![Github](https://img.shields.io/badge/Twitter-fikrado-aqua?style=for-the-badge&logo=twitter)](https://twitter.com/fikrado1)

